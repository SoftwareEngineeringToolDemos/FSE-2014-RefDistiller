package lib1;

public class Store extends Storehouse {
int extendExpirationDate(int numDays)
{
	return numDays + 2;
}
int updateExpiration(int value)
{
	return getStorageData(value);
}

public static void main(String []args)
{
	Store s = new Store();
	
	
	System.out.println(s.updateExpiration(10)+","+s.extendExpirationDate(3));
}
}
