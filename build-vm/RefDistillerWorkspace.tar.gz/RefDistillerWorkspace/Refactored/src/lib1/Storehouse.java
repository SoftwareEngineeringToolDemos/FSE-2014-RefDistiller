package lib1;

public class Storehouse {
int getStorageData(int v){
	return v+10;
}
}
