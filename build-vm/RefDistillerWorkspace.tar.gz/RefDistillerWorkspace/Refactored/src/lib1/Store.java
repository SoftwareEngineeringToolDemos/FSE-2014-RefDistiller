package lib1;

public class Store extends Storehouse {
	
	int getStorageData(int v) {
		return v - 2;
	}
int extendExpirationDate(int numDays)
{
	return getStorageData(numDays);
}
int updateExpirat(int value)
{
	return super.getStorageData(value);
}


public static void main(String []args)
{
	Store s = new Store();
	
	
	System.out.println(s.updateExpirat(10)+","+s.extendExpirationDate(3));
}
}
